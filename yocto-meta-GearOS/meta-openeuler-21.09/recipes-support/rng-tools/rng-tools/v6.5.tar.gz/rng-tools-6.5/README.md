[![Build Status](https://travis-ci.org/nhorman/rng-tools.svg?branch=master)](https://travis-ci.org/nhorman/rng-tools)

This is a random number generator daemon.

It monitors a set of entropy sources, and supplies entropy
from them to the system kernel's /dev/random machinery.

Operation is fully documented in the man page, and should be fairly intuitive


